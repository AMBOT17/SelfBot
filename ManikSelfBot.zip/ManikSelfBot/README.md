# IKYBOTV6
numpang nama tidak membuatmu pro stah

https://github.com/rizkiadiasa/IKYBOTV7/


Subscribe Iky Ads
special thanks to
doa emak
seluruh crator bot wa
Vhtear.com
mhank bar bar
dll

subscribe chanel iky ads

jng di ganti ganti kalo gamau eror

niat
2hp yg 1 buat scan
download termux
pkg install git
git clone https://github.com/rizkiadiasa/IKYBOTV7
cd IKYBOTV

ls
bash install.sh
node index.js
scan kelar
subrek iky ads gan
