[
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Haruitsuki Abeno",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2016/12/joi-abeno-featured-700x394.jpg"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Haruitsuki Abeno",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2016/12/joi-abeno-featured-700x394.jpg"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Haruitsuki Abeno",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2016/12/joi-abeno-featured-700x394.jpg"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Mikoto Mikoshiba",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/08/joi-mikorin-featured-700x394.jpg"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Kinoshita Hideyoshi",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/04/hideyoshi_cover-700x409.jpg?x21210"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Hideyuki Maya",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2017/01/joi-maya-featured-700x458.jpg"
    },
    {
	"teks": "(CEO) Orga Itsuka",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/11/joi-ceo-orga-featured-700x394.jpg"
    },
    {
	"teks": "Bakugou Katsuki",
	"image": "http://jurnalotaku.com/wp-content/uploads/2020/07/kacchan_cover1-700x409.jpg?x21210"
    },
    {
	"teks": "Slaine Troyard",
	"image": "http://jurnalotaku.com/wp-content/uploads/2019/10/husbufri-slaine-joi2-1-e1570784701581-700x421.jpg?x21210"
    },
    {
	"teks": "Takigawa Yoshino",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/husbufri-yoshino-joi10-700x394.jpg"
    },
    {
	"teks": "Azusagawa Sakuta",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/Sakuta_Azusagawa_Anime_-_Screenshot_1-700x394.png"
    },
    {
	"teks": "Willem Kmetsch",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2019/02/Films-TV-15_02_2019-21_33_37-700x394.png"
    },
    {
	"teks": "(Top Leader) Mikazuki Augus",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2018/12/joi-mikazuki-top5-700x394.jpg"
    },
    {
	"teks": "Haruitsuki Abeno",
	"image": "http://storage.jurnalotaku.com/wp-content/uploads/2016/12/joi-abeno-featured-700x394.jpg"
    }
]