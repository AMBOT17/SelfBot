const iklan = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `❀:ཻུ۪۪⸙ -----[ *IKLAN DULU GAYS* ]----- ❀:ཻུ۪۪⸙
Hallo, ${pushname} 👋
Semoga harimu Menyenangkan User, ${sender.split("@")[0]}
╭════〘 *IKY BOT* 〙════⊱❁۪۪۪
┃□╭─────────────────
┃□│⊱❥ NAMA : ${pushname}
┃□│⊱❥ LEVEL : ${getLevelingLevel(sender)}
┃□│⊱❥ USER ${botName} : ${_registered.length}
┃□╰─────────────────
╰══════════════════⊱❁۪۪۪
 ✎┊ ⊱❥ *HARGA SEWA*
╭══════════════════⊱❁۪۪۪
┃⊱❥ *1 MINGGU   5K/GRUP*
┃⊱❥ *3 MINGGU 10K/GRUP*
┃⊱❥ *1 BULAN    15K/ GRUP*
╰══════════════════⊱❁۪۪۪
✎┊ ⊱❥ *HARGA SC BOT*
╭══════════════════⊱❁۪۪۪
┃⊱❥ *SC BOT NO API/5K*
┃⊱❥ *SC+1 API=15k*
┃⊱❥ *SC+2 API=25k*
┃⊱❥ *SC+3 API=30K(DISKON)*
┃⊱❥ *SC+NAMA SENDIRI=10K(NO API)*
┃⊱❥ *SC+NAMA+1API =20K*
┃⊱❥ *SC+NAMA+2API =30K*
┃⊱❥ *SC+NAMA+3API =35K(DISKON)*
┃⊱❥ *1PAKET REQUEST NAMA+3API*
┃⊱❥  *SIAP PAKAI 50K*
┃  
┃  ⚠NOTE 3 API YA BUKAN 4⚠
┃  _MhankBarBar,Tobz,Vhtear_
╰══════════════════⊱❁۪۪۪
✎┊ ⊱❥ *BELAJAR BUAT BOT*
╭══════════════════⊱❁۪۪۪
┃⊱❥ *BELAJAR+SC NO API=20k*
┃⊱❥ *BELAJAR+SC 1 API=30K*
┃⊱❥ *BELAJAR+1PAKET=60K*
╰══════════════════⊱❁۪۪۪
✎┊ ⊱❥ *HARGA API KEY*
╭══════════════════⊱❁۪۪۪
┃⊱❥ *BarbarKey*
┃⊱❥ *15K/BULAN(800 LIMIT)*
┃⊱❥ *35K/BULAN(NO LIMIT)*
┃⊱❥ *25K/BULAN Req Nama(800 LIMIT )*
┃⊱❥ *VHTEAR KEY*
┃⊱❥ *35k+Req Nama+Unlimited/1bln*
┃⊱❥ *50k+Req Nama+Unlimited/2bln* 
╰══════════════════⊱❁۪۪۪
✎┊ ⊱❥ *PEMBAYARAN*
╭══════════════════⊱❁۪۪۪
┃⊱❥ *DANA*
┃⊱❥ *GOPAY*
┃⊱❥ *PULSA AXIS+5K* 
┃⊱❥ *RAGU?TAKUT KETIPU? SKIP*
╰══════════════════⊱❁۪۪۪

❀:ཻུ۪۪⸙ -----[ *POWERED BY ${ownerName}* ]----- ❀:ཻུ۪۪⸙`
}
exports.iklan = iklan